import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'dart:math';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Calculator(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class Calculator extends StatefulWidget {
  const Calculator({super.key});

  static AudioPlayer player = AudioPlayer();

  @override
  State<Calculator> createState() => _CalculatorState();
}

class _CalculatorState extends State<Calculator> {
  bool isDarkMode = false;
  bool isSoundEnabled = true;
  dynamic text = '0';
  double numOne = 0;
  double numTwo = 0;

  dynamic result = '';
  dynamic finalResult = '';
  dynamic opr = '';
  dynamic preOpr = '';

  void toggleDarkMode() {
    setState(() {
      isDarkMode = !isDarkMode;
    });
  }

  void toggleSound(bool value) {
    setState(() {
      isSoundEnabled = !isSoundEnabled;
    });
  }

  void calculation(txtbtn) {
    if (txtbtn == 'C') {
      text = '0';
      numOne = 0;
      numTwo = 0;
      result = '';
      finalResult = '0';
      opr = '';
      preOpr = '';
    } else if (txtbtn == 'CE') {
      result = '';
      finalResult = '0';
    } else if (txtbtn == '⌫') {
      if (result.isNotEmpty) {
        result = result.substring(0, result.length - 1);
        if (result.isEmpty) {
          result = '0';
        }
        finalResult = result;
      }
    } else if (txtbtn == 'x²') {
      if (result.isNotEmpty) {
        numOne = double.parse(result);
        result = (numOne * numOne).toString();
        finalResult = doesContainDecimal(result);
      }
    } else if (txtbtn == '√') {
      if (result == '' || result == '0') {
        numOne = numOne == 0 ? 0 : numOne;
        result = sqrt(numOne).toString();
      } else {
        numOne = double.parse(result);
        result = sqrt(numOne).toString();
      }
      finalResult = doesContainDecimal(result);
    } else if (txtbtn == '=') {
      if (opr != '') {
        numTwo = double.parse(result);

        if (opr == '+') {
          finalResult = add();
        } else if (opr == '-') {
          finalResult = sub();
        } else if (opr == 'x') {
          finalResult = mul();
        } else if (opr == '÷') {
          finalResult = div();
        }

        opr = '';
      }
    } else if (txtbtn == '+' || txtbtn == '-' || txtbtn == 'x' || txtbtn == '÷') {
      if (numOne == 0 || (opr == '' && result != '')) {
        numOne = double.parse(result);
      } else if (result != '') {
        numTwo = double.parse(result);

        if (opr == '+') {
          finalResult = add();
        } else if (opr == '-') {
          finalResult = sub();
        } else if (opr == 'x') {
          finalResult = mul();
        } else if (opr == '÷') {
          finalResult = div();
        }

        numOne = double.parse(finalResult);
      }
      opr = txtbtn;
      result = '';
    } else if (txtbtn == '%') {
      if (numOne != 0) {
        result = (numOne * (double.parse(result) / 100)).toString();
      } else {
        result = (double.parse(result) / 100).toString();
      }
      finalResult = doesContainDecimal(result);
    } else if (txtbtn == '.') {
      if (!result.toString().contains('.')) {
        result = result.toString() + '.';
      }
      finalResult = result;
    } else if (txtbtn == '⁺/₋') {
      result.toString().startsWith('-')
          ? result = result.toString().substring(1)
          : result = '-' + result.toString();
      finalResult = result;
    } else {
      result = result + txtbtn;
      finalResult = result;
    }
    setState(() {
      text = finalResult;
    });
  }

  String add() {
    result = (numOne + numTwo).toString();
    numOne = double.parse(result);
    return doesContainDecimal(result);
  }

  String sub() {
    result = (numOne - numTwo).toString();
    numOne = double.parse(result);
    return doesContainDecimal(result);
  }

  String mul() {
    result = (numOne * numTwo).toString();
    numOne = double.parse(result);
    return doesContainDecimal(result);
  }

  String div() {
    result = (numOne / numTwo).toString();
    numOne = double.parse(result);
    return doesContainDecimal(result);
  }

  String doesContainDecimal(dynamic result) {
    if (result.toString().contains('.')) {
      List<String> splitDecimal = result.toString().split('.');
      if (!(int.parse(splitDecimal[1]) > 0))
        return result = splitDecimal[0].toString();
    }
    return result;
  }

  Widget calButton(String txtbtn, Color btnclr, Color txtclr, String fileName) {
    return Expanded(
      child: Container(
        margin: EdgeInsets.all(5),
        child: ElevatedButton(
          onPressed: () {
            calculation(txtbtn);
            final player = AudioPlayer();
            if (isSoundEnabled) {
              player.play(fileName);
            }
          },
          child: Text(
            txtbtn,
            style: TextStyle(
              fontSize: 35,
              color: txtclr,
            ),
          ),
          style: ElevatedButton.styleFrom(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
            backgroundColor: btnclr,
            padding: EdgeInsets.all(20),
          ),
        ),
      ),
    );
  }

  Color getButtonColor(String txtbtn) {
    if (txtbtn == '÷' || txtbtn == 'x' || txtbtn == '-' || txtbtn == '+') {
      return isDarkMode ? Colors.amber.shade800 : Colors.orange;
    } else if (txtbtn == 'C' || txtbtn == 'CE' || txtbtn == '⌫' || txtbtn == '%' ||
        txtbtn == '⁺/₋' || txtbtn == '√' || txtbtn == 'x²') {
      return isDarkMode ? Colors.blueGrey.shade700 : Colors.black;
    } else {
      return isDarkMode ? Colors.black : Colors.grey.shade600;
    }
  }

  Color getButtonTextColor(String txtbtn) {
    return isDarkMode ? Colors.white : Colors.white;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: isDarkMode ? Colors.grey.shade900 : Colors.white,
      appBar: AppBar(
        title: Text(
          "Calculator",
          style: TextStyle(color: isDarkMode ? Colors.white : Colors.black),
        ),
        backgroundColor: isDarkMode ? Colors.grey.shade900 : Colors.white,
        centerTitle: true,
        leading: IconButton(
          icon: Text(
            '☾',
            style: TextStyle(
              fontSize: 24,
              color: isDarkMode ? Colors.white : Colors.black,
            ),
          ),
          onPressed: toggleDarkMode,
        ),
          actions: [
          Padding(padding: const EdgeInsets.fromLTRB(15.0, 0, 0, 7),
          child: Text("☾", style: TextStyle(
            fontSize: 35,
            color: isDarkMode ? Colors.white : Colors.black,
          ),
          ),
        ),
            Switch(
              value: isSoundEnabled,
              onChanged: toggleSound,
              activeColor: Colors.greenAccent,
              inactiveThumbColor: Colors.grey,
            ),
        ],
      ),
      body: GestureDetector(
        onHorizontalDragEnd: (details) {
          if (details.primaryVelocity! < 10) {
            setState(() {
              calculation('C');
            });
          }
        },
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 5),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Padding(
                    padding: EdgeInsets.all(10.0),
                    child: Text(
                      text,
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        color: isDarkMode ? Colors.white : Colors.black,
                        fontSize: 90,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    '$numOne',
                    style: TextStyle(
                      color: isDarkMode ? Colors.white : Colors.black,
                      fontSize: 20,
                    ),
                  ),
                  Text(
                    '$opr',
                    style: TextStyle(
                      color: isDarkMode ? Colors.white : Colors.black,
                      fontSize: 20,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 10),
              buildButtonRow(['%', 'C', 'CE', '⌫']),
              buildButtonRow(['⁺/₋', 'x²', '√', '÷']),
              buildButtonRow(['7', '8', '9', 'x']),
              buildButtonRow(['4', '5', '6', '-']),
              buildButtonRow(['1', '2', '3', '+']),
              buildButtonRow(['0', '00', '.', '=']),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildButtonRow(List<String> buttons) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: buttons
          .map((txtbtn) => calButton(
        txtbtn,
        getButtonColor(txtbtn),
        getButtonTextColor(txtbtn), 'FileName'
      ))
          .toList(),
    );
  }
}