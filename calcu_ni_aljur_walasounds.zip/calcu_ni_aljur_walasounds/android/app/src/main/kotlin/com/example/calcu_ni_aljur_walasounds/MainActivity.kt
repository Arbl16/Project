package com.example.calcu_ni_aljur_walasounds

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
